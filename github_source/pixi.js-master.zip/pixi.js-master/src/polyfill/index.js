require('./Object.assign');
require('./requestAnimationFrame');
