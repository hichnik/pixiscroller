describe('pixi/extras/Spine', function () {
    'use strict';

    var expect = chai.expect;
    var Spine = PIXI.Spine;

    it('Module exists', function () {
        expect(Spine).to.be.a('function');
    });
});
