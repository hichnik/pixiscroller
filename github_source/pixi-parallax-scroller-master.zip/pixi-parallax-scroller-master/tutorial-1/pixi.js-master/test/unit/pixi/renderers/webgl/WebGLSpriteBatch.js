describe('renderers/webgl/utils/WebGLSpriteBatch', function () {
    'use strict';

    var expect = chai.expect;
    var WebGLSpriteBatch = PIXI.WebGLSpriteBatch;

    it('Module exists', function () {
        expect(WebGLSpriteBatch).to.be.a('function');
    });
});
