describe('pixi/InteractionManager', function () {
    'use strict';

    var expect = chai.expect;
    var InteractionManager = PIXI.InteractionManager;

    it('Module exists', function () {
        expect(InteractionManager).to.be.a('function');
    });
});
