describe('pixi/loaders/SpineLoader', function () {
    'use strict';

    var expect = chai.expect;
    var SpineLoader = PIXI.SpineLoader;

    it('Module exists', function () {
        expect(SpineLoader).to.be.a('function');
    });
});
