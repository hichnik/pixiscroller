describe('pixi/loaders/BitmapFontLoader', function () {
    'use strict';

    var expect = chai.expect;

    it('Module exists', function () {
        expect(PIXI.BitmapFontLoader).to.be.a('function');
    });
});
