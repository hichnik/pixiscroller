describe('pixi/text/Text', function () {
    'use strict';

    var expect = chai.expect;
    var Text = PIXI.Text;

    it('Module exists', function () {
        expect(Text).to.be.a('function');
    });
});
