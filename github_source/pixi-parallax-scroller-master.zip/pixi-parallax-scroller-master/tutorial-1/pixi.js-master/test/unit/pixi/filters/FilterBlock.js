describe('pixi/filters/FilterBlock', function () {
    'use strict';

    var expect = chai.expect;
    var FilterBlock = PIXI.FilterBlock;

    it('Module exists', function () {
        expect(FilterBlock).to.be.a('function');
    });
});
