/**
 * @author Mat Groves http://matgroves.com/ @Doormat23
 */

/**
 * A target and pass info object for filters.
 * 
 * @class FilterBlock
 * @constructor
 */
PIXI.FilterBlock = function()
{
    /**
     * The visible state of this FilterBlock.
     *
     * @property visible
     * @type Boolean
     */
    this.visible = true;

    /**
     * The renderable state of this FilterBlock.
     *
     * @property renderable
     * @type Boolean
     */
    this.renderable = true;
};

PIXI.FilterBlock.prototype.constructor = PIXI.FilterBlock;
