Building a Parallax Scroller with Pixi.js Tutorial: Part 1
==========================================================

This is the accompanying source code for part 1 of *[Building a Parallax Scroller with Pixi.js Tutorial](http://www.yeahbutisitflash.com/?p=5226)* by *[Christopher Caleb](http://www.yeahbutisitflash.com/?page_id=2)*.

Artwork by *[Marcus Gray](http://gray-marcus.wix.com/grayillustration)*.
